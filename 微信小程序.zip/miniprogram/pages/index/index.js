const app = getApp();
const db = wx.cloud.database();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    height:0,
    array:[{img:'./img/one.png',name:'美食'},
  {img:'./img/two.png',name:'闹钟'},
{img:'./img/three.png',name:'导航'},
{img:'./img/four.png',name:'视频'},
{img:'./img/five.png',name:'赛程'}],
 
    array_tuijian:[

    ],
    openid:'',
    search:'',
    search_product:[],
    searching:false
    // navH:null
  },
  
  // 跳转导航
  selectName(res){
    wx.navigateTo({
      url: '../map/map',
    })
  },
  // 跳转掌柜推荐
  BossRecommend(res){
    wx.navigateTo({
      url: '../recommend/recommend',
    })
  },
  
  setContainerHeight:function(e){
    //图片的原始宽度
    var imgWidth=e.detail.width;
    //图片的原始高度
    var imgHeight=e.detail.height;
    //同步获取设备宽度
    var sysInfo=wx.getSystemInfoSync();
    //获取屏幕的高度
    var screenWidth=sysInfo.screenWidth;
    //获取屏幕和原图的比例
    var scale=screenWidth/imgWidth;
    //设置容器的高度
    this.setData({
      height:imgHeight*scale
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      // swiper设置高度
    // var that = this;
    // that.setData({
    //   navH: app.globalData.navHeight
    // })
    // console.log(that.data.navH)
    var that = this;
    var array = [];
    // console.log(x,i);
    wx.cloud.callFunction({
      name:'findProduct',
      success(res){
        for(var i = 0; i < res.result.data.length; i++){
          if(res.result.data[i].isRecommend == '是'){
            array.push(res.result.data[i])
          }
        }
        that.setData({
          array_tuijian:array
        })
      }
    })
    wx.cloud.callFunction({
      name:'OpenId',
      success(res){
        that.setData({
          openid:res.result.openid
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.onLoad();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})