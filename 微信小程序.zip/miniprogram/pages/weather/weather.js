const db = wx.cloud.database();
const app = getApp();
Page({
  data: {
    region:['北京市','北京市','东城区'],
    now:[],
    locationID:'101010100'
  },

 changeRegion:function(e){
   this.setData({
     region:e.detail.value,
   })
   this.getLocationID();
   this.getWeater();   //更新天气
 },
 //获取位置
 getLocationID:function(){
   var that=this;
   wx.request({
    url: 'https://geoapi.qweather.com/v2/city/lookup?',
    data:{
      location:that.data.region[2],
      key: '5eb79525ab604259b688e5713c96c808'
    },
    success:function(res){
       //console.log(res)
       that.setData({
        locationID:res.data.location[0].id,
      })
     }
   })
 },
 
 getDovData:function(){
   var that=this;
   wx.request({
    type: "get",
    url: "https://uaqy.api.storeapi.net/api/94/219?format=json&appid=6254&sign=f8621000dee76d6def53b5a53fece102",
    dataType: "json",
    success: function (res) {
          //console.log(res);
    }
   })
 },
 getWeater:function(){
   var that=this;      //this不可以直接在wxAPI函数中直接使用
   wx.request({
     url: 'https://devapi.qweather.com/v7/weather/now?',
     data:{
       location:that.data.locationID,
       key: '5eb79525ab604259b688e5713c96c808'
     },
     success:function(res){
      //console.log(res)
       that.setData({
         now:res.data.now,
       })
     }
   })
 },
  onLoad: function (options) {
    this.getLocationID();
    this.getWeater();
    this.getDovData();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.onLoad();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})